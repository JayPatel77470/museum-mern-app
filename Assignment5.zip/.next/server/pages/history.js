/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/history";
exports.ids = ["pages/history"];
exports.modules = {

/***/ "./styles/History.module.css":
/*!***********************************!*\
  !*** ./styles/History.module.css ***!
  \***********************************/
/***/ ((module) => {

eval("// Exports\nmodule.exports = {\n\t\"historyListItem\": \"History_historyListItem__2_I8Z\"\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zdHlsZXMvSGlzdG9yeS5tb2R1bGUuY3NzLmpzIiwibWFwcGluZ3MiOiJBQUFBO0FBQ0E7QUFDQTtBQUNBIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vbXktYXBwLy4vc3R5bGVzL0hpc3RvcnkubW9kdWxlLmNzcz80Yjk3Il0sInNvdXJjZXNDb250ZW50IjpbIi8vIEV4cG9ydHNcbm1vZHVsZS5leHBvcnRzID0ge1xuXHRcImhpc3RvcnlMaXN0SXRlbVwiOiBcIkhpc3RvcnlfaGlzdG9yeUxpc3RJdGVtX18yX0k4WlwiXG59O1xuIl0sIm5hbWVzIjpbXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./styles/History.module.css\n");

/***/ }),

/***/ "./pages/history.js":
/*!**************************!*\
  !*** ./pages/history.js ***!
  \**************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var jotai__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! jotai */ \"jotai\");\n/* harmony import */ var _store__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../store */ \"./store.js\");\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! next/router */ \"next/router\");\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);\n/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react-bootstrap */ \"react-bootstrap\");\n/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap__WEBPACK_IMPORTED_MODULE_4__);\n/* harmony import */ var _styles_History_module_css__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../styles/History.module.css */ \"./styles/History.module.css\");\n/* harmony import */ var _styles_History_module_css__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_styles_History_module_css__WEBPACK_IMPORTED_MODULE_5__);\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([jotai__WEBPACK_IMPORTED_MODULE_1__, _store__WEBPACK_IMPORTED_MODULE_2__]);\n([jotai__WEBPACK_IMPORTED_MODULE_1__, _store__WEBPACK_IMPORTED_MODULE_2__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);\n\n\n\n\n\n\n\n\nconst History = ()=>{\n    const [searchHistory, setSearchHistory] = (0,jotai__WEBPACK_IMPORTED_MODULE_1__.useAtom)(_store__WEBPACK_IMPORTED_MODULE_2__.searchHistoryAtom);\n    let parsedHistory = [];\n    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_3__.useRouter)();\n    function historyClicked(e, index) {\n        router.push(`/artwork?${searchHistory[index]}`);\n    }\n    function removeHistoryClicked(e, index) {\n        e.stopPropagation();\n        setSearchHistory((curr)=>{\n            let x = [\n                ...curr\n            ];\n            x.splice(index, 1);\n            return x;\n        });\n    }\n    searchHistory.forEach((item)=>{\n        let params = new URLSearchParams(item);\n        let entries = params.entries();\n        parsedHistory.push(Object.fromEntries(entries));\n    });\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {\n        children: parsedHistory.length > 0 ? /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_bootstrap__WEBPACK_IMPORTED_MODULE_4__.ListGroup, {\n            children: parsedHistory.map((historyItem, index)=>{\n                return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_bootstrap__WEBPACK_IMPORTED_MODULE_4__.ListGroup.Item, {\n                    className: (_styles_History_module_css__WEBPACK_IMPORTED_MODULE_5___default().historyListItem),\n                    onClick: (e)=>historyClicked(e, index),\n                    children: [\n                        Object.keys(historyItem).map((key)=>{\n                            return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {\n                                children: [\n                                    key,\n                                    \": \",\n                                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"strong\", {\n                                        children: historyItem[key]\n                                    }, void 0, false, {\n                                        fileName: \"D:\\\\Seneca Sem 4\\\\WEB422\\\\Assignment5\\\\my-app\\\\pages\\\\history.js\",\n                                        lineNumber: 39,\n                                        columnNumber: 93\n                                    }, undefined),\n                                    \"\\xa0\"\n                                ]\n                            }, void 0, true);\n                        }),\n                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_bootstrap__WEBPACK_IMPORTED_MODULE_4__.Button, {\n                            className: \"float-end\",\n                            variant: \"danger\",\n                            size: \"sm\",\n                            onClick: (e)=>removeHistoryClicked(e, index),\n                            children: \"\\xd7\"\n                        }, void 0, false, {\n                            fileName: \"D:\\\\Seneca Sem 4\\\\WEB422\\\\Assignment5\\\\my-app\\\\pages\\\\history.js\",\n                            lineNumber: 40,\n                            columnNumber: 37\n                        }, undefined)\n                    ]\n                }, index, true, {\n                    fileName: \"D:\\\\Seneca Sem 4\\\\WEB422\\\\Assignment5\\\\my-app\\\\pages\\\\history.js\",\n                    lineNumber: 38,\n                    columnNumber: 33\n                }, undefined);\n            })\n        }, void 0, false, {\n            fileName: \"D:\\\\Seneca Sem 4\\\\WEB422\\\\Assignment5\\\\my-app\\\\pages\\\\history.js\",\n            lineNumber: 35,\n            columnNumber: 21\n        }, undefined) : /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_bootstrap__WEBPACK_IMPORTED_MODULE_4__.Card, {\n            children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_bootstrap__WEBPACK_IMPORTED_MODULE_4__.Card.Body, {\n                children: [\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"h4\", {\n                        children: \"Nothing Here\"\n                    }, void 0, false, {\n                        fileName: \"D:\\\\Seneca Sem 4\\\\WEB422\\\\Assignment5\\\\my-app\\\\pages\\\\history.js\",\n                        lineNumber: 47,\n                        columnNumber: 29\n                    }, undefined),\n                    \"Try searching for some artwork.\"\n                ]\n            }, void 0, true, {\n                fileName: \"D:\\\\Seneca Sem 4\\\\WEB422\\\\Assignment5\\\\my-app\\\\pages\\\\history.js\",\n                lineNumber: 46,\n                columnNumber: 25\n            }, undefined)\n        }, void 0, false, {\n            fileName: \"D:\\\\Seneca Sem 4\\\\WEB422\\\\Assignment5\\\\my-app\\\\pages\\\\history.js\",\n            lineNumber: 45,\n            columnNumber: 21\n        }, undefined)\n    }, void 0, false);\n};\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (History);\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9oaXN0b3J5LmpzLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFBK0I7QUFDYTtBQUNMO0FBQ0k7QUFDSDtBQUNTO0FBQ1g7QUFFdEMsTUFBTU8sVUFBVSxJQUFNO0lBQ2xCLE1BQU0sQ0FBQ0MsZUFBZUMsaUJBQWlCLEdBQUdULDhDQUFPQSxDQUFDQyxxREFBaUJBO0lBQ25FLElBQUlTLGdCQUFnQixFQUFFO0lBQ3RCLE1BQU1DLFNBQVNULHNEQUFTQTtJQUV4QixTQUFTVSxlQUFlQyxDQUFDLEVBQUVDLEtBQUssRUFBRTtRQUM5QkgsT0FBT0ksSUFBSSxDQUFDLENBQUMsU0FBUyxFQUFFUCxhQUFhLENBQUNNLE1BQU0sQ0FBQyxDQUFDO0lBQ2xEO0lBRUEsU0FBU0UscUJBQXFCSCxDQUFDLEVBQUVDLEtBQUssRUFBRTtRQUNwQ0QsRUFBRUksZUFBZTtRQUNqQlIsaUJBQWlCUyxDQUFBQSxPQUFRO1lBQ3JCLElBQUlDLElBQUk7bUJBQUlEO2FBQUs7WUFDakJDLEVBQUVDLE1BQU0sQ0FBQ04sT0FBTztZQUNoQixPQUFPSztRQUNYO0lBQ0o7SUFDQVgsY0FBY2EsT0FBTyxDQUFDQyxDQUFBQSxPQUFRO1FBQzFCLElBQUlDLFNBQVMsSUFBSUMsZ0JBQWdCRjtRQUNqQyxJQUFJRyxVQUFVRixPQUFPRSxPQUFPO1FBQzVCZixjQUFjSyxJQUFJLENBQUNXLE9BQU9DLFdBQVcsQ0FBQ0Y7SUFDMUM7SUFDQSxxQkFDSTtrQkFFUWYsY0FBY2tCLE1BQU0sR0FBRyxrQkFDbkIsOERBQUN6QixzREFBU0E7c0JBQ0xPLGNBQWNtQixHQUFHLENBQUMsQ0FBQ0MsYUFBYWhCLFFBQVU7Z0JBQ3ZDLHFCQUNJLDhEQUFDWCwyREFBYztvQkFBYTZCLFdBQVczQixtRkFBc0I7b0JBQUU2QixTQUFTckIsQ0FBQUEsSUFBS0QsZUFBZUMsR0FBR0M7O3dCQUMxRlksT0FBT1MsSUFBSSxDQUFDTCxhQUFhRCxHQUFHLENBQUNPLENBQUFBLE1BQU87NEJBQUUscUJBQVE7O29DQUFHQTtvQ0FBSTtrREFBRSw4REFBQ0M7a0RBQVFQLFdBQVcsQ0FBQ00sSUFBSTs7Ozs7O29DQUFVOzs7d0JBQVc7c0NBQ3RHLDhEQUFDaEMsbURBQU1BOzRCQUFDNEIsV0FBVTs0QkFBWU0sU0FBUTs0QkFBU0MsTUFBSzs0QkFBS0wsU0FBU3JCLENBQUFBLElBQUtHLHFCQUFxQkgsR0FBR0M7c0NBQVE7Ozs7Ozs7bUJBRnRGQTs7Ozs7WUFLN0I7Ozs7O3NDQUVKLDhEQUFDUixpREFBSUE7c0JBQ0QsNEVBQUNBLHNEQUFTOztrQ0FDTiw4REFBQ21DO2tDQUFHOzs7Ozs7b0JBQWlCOzs7Ozs7Ozs7OztxQkFHdEI7O0FBSTNCO0FBRUEsaUVBQWVsQyxPQUFPQSxFQUFBIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vbXktYXBwLy4vcGFnZXMvaGlzdG9yeS5qcz9mNjI4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZUF0b20gfSBmcm9tIFwiam90YWlcIlxyXG5pbXBvcnQgeyBzZWFyY2hIaXN0b3J5QXRvbSB9IGZyb20gXCIuLi9zdG9yZVwiXHJcbmltcG9ydCB7IHVzZVJvdXRlciB9IGZyb20gXCJuZXh0L3JvdXRlclwiXHJcbmltcG9ydCB7IExpc3RHcm91cCB9IGZyb20gXCJyZWFjdC1ib290c3RyYXBcIlxyXG5pbXBvcnQgeyBCdXR0b24gfSBmcm9tIFwicmVhY3QtYm9vdHN0cmFwXCJcclxuaW1wb3J0IHN0eWxlcyBmcm9tIFwiLi4vc3R5bGVzL0hpc3RvcnkubW9kdWxlLmNzc1wiXHJcbmltcG9ydCB7IENhcmQgfSBmcm9tIFwicmVhY3QtYm9vdHN0cmFwXCJcclxuXHJcbmNvbnN0IEhpc3RvcnkgPSAoKSA9PiB7XHJcbiAgICBjb25zdCBbc2VhcmNoSGlzdG9yeSwgc2V0U2VhcmNoSGlzdG9yeV0gPSB1c2VBdG9tKHNlYXJjaEhpc3RvcnlBdG9tKVxyXG4gICAgbGV0IHBhcnNlZEhpc3RvcnkgPSBbXVxyXG4gICAgY29uc3Qgcm91dGVyID0gdXNlUm91dGVyKClcclxuXHJcbiAgICBmdW5jdGlvbiBoaXN0b3J5Q2xpY2tlZChlLCBpbmRleCkge1xyXG4gICAgICAgIHJvdXRlci5wdXNoKGAvYXJ0d29yaz8ke3NlYXJjaEhpc3RvcnlbaW5kZXhdfWApXHJcbiAgICB9XHJcblxyXG4gICAgZnVuY3Rpb24gcmVtb3ZlSGlzdG9yeUNsaWNrZWQoZSwgaW5kZXgpIHtcclxuICAgICAgICBlLnN0b3BQcm9wYWdhdGlvbigpO1xyXG4gICAgICAgIHNldFNlYXJjaEhpc3RvcnkoY3VyciA9PiB7XHJcbiAgICAgICAgICAgIGxldCB4ID0gWy4uLmN1cnJdXHJcbiAgICAgICAgICAgIHguc3BsaWNlKGluZGV4LCAxKVxyXG4gICAgICAgICAgICByZXR1cm4geFxyXG4gICAgICAgIH0pXHJcbiAgICB9XHJcbiAgICBzZWFyY2hIaXN0b3J5LmZvckVhY2goaXRlbSA9PiB7XHJcbiAgICAgICAgbGV0IHBhcmFtcyA9IG5ldyBVUkxTZWFyY2hQYXJhbXMoaXRlbSk7XHJcbiAgICAgICAgbGV0IGVudHJpZXMgPSBwYXJhbXMuZW50cmllcygpO1xyXG4gICAgICAgIHBhcnNlZEhpc3RvcnkucHVzaChPYmplY3QuZnJvbUVudHJpZXMoZW50cmllcykpO1xyXG4gICAgfSlcclxuICAgIHJldHVybiAoXHJcbiAgICAgICAgPD5cclxuICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgcGFyc2VkSGlzdG9yeS5sZW5ndGggPiAwID9cclxuICAgICAgICAgICAgICAgICAgICA8TGlzdEdyb3VwPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7cGFyc2VkSGlzdG9yeS5tYXAoKGhpc3RvcnlJdGVtLCBpbmRleCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8TGlzdEdyb3VwLkl0ZW0ga2V5PXtpbmRleH0gY2xhc3NOYW1lPXtzdHlsZXMuaGlzdG9yeUxpc3RJdGVtfSBvbkNsaWNrPXtlID0+IGhpc3RvcnlDbGlja2VkKGUsIGluZGV4KX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtPYmplY3Qua2V5cyhoaXN0b3J5SXRlbSkubWFwKGtleSA9PiB7IHJldHVybiAoPD57a2V5fTogPHN0cm9uZz57aGlzdG9yeUl0ZW1ba2V5XX08L3N0cm9uZz4mbmJzcDs8Lz4pIH0pfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8QnV0dG9uIGNsYXNzTmFtZT1cImZsb2F0LWVuZFwiIHZhcmlhbnQ9XCJkYW5nZXJcIiBzaXplPVwic21cIiBvbkNsaWNrPXtlID0+IHJlbW92ZUhpc3RvcnlDbGlja2VkKGUsIGluZGV4KX0+JnRpbWVzOzwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvTGlzdEdyb3VwLkl0ZW0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvTGlzdEdyb3VwPiA6XHJcbiAgICAgICAgICAgICAgICAgICAgPENhcmQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxDYXJkLkJvZHk+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aDQ+Tm90aGluZyBIZXJlPC9oND5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFRyeSBzZWFyY2hpbmcgZm9yIHNvbWUgYXJ0d29yay5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9DYXJkLkJvZHk+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9DYXJkPlxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgPC8+XHJcbiAgICApXHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IEhpc3RvcnlcclxuIl0sIm5hbWVzIjpbInVzZUF0b20iLCJzZWFyY2hIaXN0b3J5QXRvbSIsInVzZVJvdXRlciIsIkxpc3RHcm91cCIsIkJ1dHRvbiIsInN0eWxlcyIsIkNhcmQiLCJIaXN0b3J5Iiwic2VhcmNoSGlzdG9yeSIsInNldFNlYXJjaEhpc3RvcnkiLCJwYXJzZWRIaXN0b3J5Iiwicm91dGVyIiwiaGlzdG9yeUNsaWNrZWQiLCJlIiwiaW5kZXgiLCJwdXNoIiwicmVtb3ZlSGlzdG9yeUNsaWNrZWQiLCJzdG9wUHJvcGFnYXRpb24iLCJjdXJyIiwieCIsInNwbGljZSIsImZvckVhY2giLCJpdGVtIiwicGFyYW1zIiwiVVJMU2VhcmNoUGFyYW1zIiwiZW50cmllcyIsIk9iamVjdCIsImZyb21FbnRyaWVzIiwibGVuZ3RoIiwibWFwIiwiaGlzdG9yeUl0ZW0iLCJJdGVtIiwiY2xhc3NOYW1lIiwiaGlzdG9yeUxpc3RJdGVtIiwib25DbGljayIsImtleXMiLCJrZXkiLCJzdHJvbmciLCJ2YXJpYW50Iiwic2l6ZSIsIkJvZHkiLCJoNCJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./pages/history.js\n");

/***/ }),

/***/ "./store.js":
/*!******************!*\
  !*** ./store.js ***!
  \******************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"favouritesAtom\": () => (/* binding */ favouritesAtom),\n/* harmony export */   \"searchHistoryAtom\": () => (/* binding */ searchHistoryAtom)\n/* harmony export */ });\n/* harmony import */ var jotai__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! jotai */ \"jotai\");\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([jotai__WEBPACK_IMPORTED_MODULE_0__]);\njotai__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];\n\nconst favouritesAtom = (0,jotai__WEBPACK_IMPORTED_MODULE_0__.atom)([]);\nconst searchHistoryAtom = (0,jotai__WEBPACK_IMPORTED_MODULE_0__.atom)([]);\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zdG9yZS5qcy5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7QUFBNEI7QUFFckIsTUFBTUMsaUJBQWlCRCwyQ0FBSUEsQ0FBQyxFQUFFLEVBQUM7QUFDL0IsTUFBTUUsb0JBQW9CRiwyQ0FBSUEsQ0FBQyxFQUFFLEVBQUMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9teS1hcHAvLi9zdG9yZS5qcz80MGY1Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGF0b20gfSBmcm9tIFwiam90YWlcIlxyXG5cclxuZXhwb3J0IGNvbnN0IGZhdm91cml0ZXNBdG9tID0gYXRvbShbXSlcclxuZXhwb3J0IGNvbnN0IHNlYXJjaEhpc3RvcnlBdG9tID0gYXRvbShbXSkiXSwibmFtZXMiOlsiYXRvbSIsImZhdm91cml0ZXNBdG9tIiwic2VhcmNoSGlzdG9yeUF0b20iXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./store.js\n");

/***/ }),

/***/ "next/router":
/*!******************************!*\
  !*** external "next/router" ***!
  \******************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ "react-bootstrap":
/*!**********************************!*\
  !*** external "react-bootstrap" ***!
  \**********************************/
/***/ ((module) => {

"use strict";
module.exports = require("react-bootstrap");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-dev-runtime");

/***/ }),

/***/ "jotai":
/*!************************!*\
  !*** external "jotai" ***!
  \************************/
/***/ ((module) => {

"use strict";
module.exports = import("jotai");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/history.js"));
module.exports = __webpack_exports__;

})();